from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import sqlite3
import os
import re
import google.generativeai as genai
import requests
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "default_secret_key")

# Configure the API key
GOOGLE_GEMINI_KEY = os.getenv("GOOGLE_GEMINI_KEY")
genai.configure(api_key=GOOGLE_GEMINI_KEY)

# Database setup
def init_db():
    conn = sqlite3.connect('recipedata.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    password TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS recipes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    recipe_name TEXT,
                    ingredients TEXT,
                    instructions TEXT,
                    tips TEXT,
                    nutrition TEXT,
                    prep_time INTEGER,
                    servings INTEGER,
                    total_calories INTEGER,
                    FOREIGN KEY(user_id) REFERENCES users(id))''')
    conn.commit()
    conn.close()

# Initialize the Gemini 2.0 Flash model
model = genai.GenerativeModel(model_name="gemini-2.0-flash")

def get_gemini_response(prompt, question):
    try:
        response = model.generate_content(f"{prompt}\n\n{question}")
        return response.text
    except Exception as e:
        print(f"Error generating content: {e}")
        return None

# Fetch recipe image
def fetch_recipe_image(recipe_name):
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")  # Ensure this is set in your .env file
    SEARCH_ENGINE_ID = os.getenv("SEARCH_ENGINE_ID")  # Ensure this is set in your .env file
    try:
        url = "https://www.googleapis.com/customsearch/v1"
        params = {
            "q": recipe_name,
            "cx": SEARCH_ENGINE_ID,
            "key": GOOGLE_API_KEY,
            "searchType": "image",
            "num": 1,
        }
        response = requests.get(url, params=params)
        response.raise_for_status()
        results = response.json().get("items", [])
        if results:
            return results[0]["link"]
    except requests.exceptions.RequestException as e:
        print(f"Image API error: {e}")
    return "https://via.placeholder.com/300"  # Fallback image

def parse_recipe_response(response):
    recipe = {
        "recipe_name": "",
        "ingredients": "",
        "instructions": "",
        "tips": "",
        "nutrition": "",
    }

    # Debugging: Print the raw response
    print("Raw Gemini Response:", response)

    # Extract Recipe Name
    recipe_name_match = re.search(r'Recipe Name:\s*(.+)', response, re.IGNORECASE)
    if recipe_name_match:
        recipe["recipe_name"] = recipe_name_match.group(1).strip()

    # Extract Ingredients
    ingredients_match = re.search(r'Ingredients:\s*([\s\S]*?)(Instructions:|Tips:|Nutrition Information:|$)', response, re.IGNORECASE)
    if ingredients_match:
        ingredients = ingredients_match.group(1).strip()
        # Format ingredients into a bulleted list
        ingredients_list = [f"- {line.strip()}" for line in ingredients.split('\n') if line.strip()]
        recipe["ingredients"] = "\n".join(ingredients_list)

    # Extract Instructions
    instructions_match = re.search(r'Instructions:\s*([\s\S]*?)(Tips:|Nutrition Information:|$)', response, re.IGNORECASE)
    if instructions_match:
        instructions = instructions_match.group(1).strip()
        # Format instructions into a numbered list
        instructions_list = [f"{i+1}. {line.strip()}" for i, line in enumerate(instructions.split('\n')) if line.strip()]
        recipe["instructions"] = "\n".join(instructions_list)

    # Extract Tips (excluding Nutrition Information)
    tips_match = re.search(r'Tips:\s*([\s\S]*?)(Nutrition Information:|$)', response, re.IGNORECASE)
    if tips_match:
        tips_content = tips_match.group(1).strip()
        # Remove Nutrition Information from Tips
        tips_content = re.sub(r'Nutrition Information:\s*([\s\S]*)', '', tips_content, flags=re.IGNORECASE)
        # Format tips into a bulleted list
        tips_list = [f"- {line.strip()}" for line in tips_content.split('\n') if line.strip()]
        recipe["tips"] = "\n".join(tips_list)

    # Extract Nutrition Information
    nutrition_match = re.search(r'Nutrition Information:\s*([\s\S]*)', response, re.IGNORECASE)
    if nutrition_match:
        nutrition = nutrition_match.group(1).strip()
        # Format nutrition into a bulleted list
        nutrition_list = [f"- {line.strip()}" for line in nutrition.split('\n') if line.strip()]
        recipe["nutrition"] = "\n".join(nutrition_list)

    # Debugging: Print the parsed recipe
    print("Parsed Recipe:", recipe)

    return recipe

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('recipedata.db')
        c = conn.cursor()
        c.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        conn.commit()
        conn.close()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('recipedata.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            return redirect(url_for('generate_recipe'))
        else:
            return "Invalid credentials!"
    return render_template('login.html')

@app.route('/generate_recipe', methods=['GET', 'POST'])
def generate_recipe():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        session['cuisine'] = request.form['cuisine']
        session['meal_type'] = request.form['meal_type']
        session['diet'] = request.form['diet']
        session['prep_time'] = request.form['prep_time']
        session['servings'] = request.form['servings']
        session['ingredients'] = request.form['ingredients']
        session['unwanted_ingredients'] = request.form['unwanted_ingredients']
        
        cuisine = session.get('cuisine', '')
        meal_type = session.get('meal_type', '')
        diet = session.get('diet', '')
        prep_time = session.get('prep_time', '')
        servings = session.get('servings', '')
        ingredients = session.get('ingredients', '')
        unwanted_ingredients = session.get('unwanted_ingredients', '')

        question = f"""
        Create a recipe for a {meal_type} in {cuisine} cuisine that adheres to a {diet} diet. 
        It should take less than {prep_time} minutes to prepare, serve {servings} people, and include the following ingredients: {ingredients}. 
        Avoid using these ingredients: {unwanted_ingredients}.
        """

        prompt = """
        You are an expert in generating recipes. Generate a detailed recipe including:
        - Recipe Name: <name>
        - Ingredients: <list of ingredients with quantities and calories>
        - Instructions: <step-by-step instructions>
        - Tips: <cooking tips>
        - Nutrition Information: <nutritional details>
        """

        recipe_response = get_gemini_response(prompt, question)
        if not recipe_response:
            return "Error generating recipe. Please try again.", 500

        # Parse the recipe response
        recipe = parse_recipe_response(recipe_response)

        # Calculate total calories
        total_calories = 0
        for line in recipe["ingredients"].split('\n'):
            if line.strip():
                try:
                    # Extracts the first numeric value from the calorie string
                    calories_match = re.search(r'(\d+)\s*(?:calories|calorie)', line)
                    if calories_match:
                         total_calories += int(calories_match.group(1))
                except ValueError:
                    continue  # Skip lines where conversion fails

        conn = sqlite3.connect('recipedata.db')
        c = conn.cursor()
        c.execute('INSERT INTO recipes (user_id, recipe_name, ingredients, instructions, tips, nutrition, prep_time, servings, total_calories) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                  (session['user_id'], recipe["recipe_name"], recipe["ingredients"], recipe["instructions"], recipe["tips"], recipe["nutrition"], prep_time, servings, total_calories))
        recipe_id = c.lastrowid 
        conn.commit()
        conn.close()

        return redirect(url_for('view_recipe', recipe_id=recipe_id))
    return render_template('generate_recipe.html')

@app.route('/view_recipe/<int:recipe_id>')
def view_recipe(recipe_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = sqlite3.connect('recipedata.db')
    c = conn.cursor()
    
    c.execute('''SELECT recipe_name, ingredients, instructions, tips, nutrition, prep_time, servings, total_calories 
                 FROM recipes WHERE id = ? AND user_id = ?''', (recipe_id, session['user_id']))
    
    recipe = c.fetchone()
    conn.close()

    if not recipe:
        return "Recipe not found!", 404

    recipe_image = fetch_recipe_image(recipe[0])

    return render_template('view_recipes.html', recipe=recipe, recipe_image=recipe_image)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)